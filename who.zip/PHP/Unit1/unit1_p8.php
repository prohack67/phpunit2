<!-- write a PHP program to display information of PHP in the browser. -->
 <?php
 echo "php version=".phpversion();
 Phpinfo();
 phpinfo(INFO_MODULES);
 ?>