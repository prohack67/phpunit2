<!-- create a program in PHP to demonstrate the use of if... Else and switch statements -->
 <!doctype html>
 <html>
    <head>
        <meta charset="utf-8">
        <title>Untitled Document</title>
    </head>
    <body>
        <?php
        $age="25";
        $gender="f";
        if($age>18)
        {
            if($gender=='M'||$gender=='m')
            {
                echo"Your are aligible for Vote and you are male candidate";
            }
            else
            {
                echo("Your are aligible for vote and are Female candidate");
            }
        }
        else
            {
                print("You are not aligible for Vote...");
            }
        switch(true){
            case($age<18):
                echo "you are not eligible for vote<br>";
                break;
                case($age>18):
                    echo "you are eligible for vote<br>";
                    break;
                    echo"you are also eligible";
        }
            ?>
    </body>
 </html>