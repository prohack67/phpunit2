<?php
//Index Array
$arr=array(11,22,33,44,55,66);
Echo$arr[3];
//Associative Array
$student=array("name"=>"Shriya Amin","age"=>20,"height"=>5.0);
echo"<br>".$student["name"];
echo"<br>".$student["age"];
echo"<br>".$student["height"];
// Multi-dimensional
 $emp=array("Name"=>array("ram","Mohan","Shiva"),
            "Salary"=>array(10000,20000,30000), 
            "Designation"=>array("Manager","Sr.Developer","Team Leader"));
 echo"<br>".$emp["Name"][1];
 echo"<br>".$emp["Salary"][1];
 echo"<br>".$emp["Designation"][1]."<br>";
//Important inbuilt functions in Array
//print()
$arr=array(1,2,3,4,5,6);
print_r($arr);
//count()
$a=array(1,2,3,4,5,6,7);
$len=count($a);
echo"<br>".$len."<br>";
for($j=0;$j<count($a);$j++)
{
    echo$a[$j];
}
//Sizeof()
$a=array(1,2,3,4,5,6,7);
$len=sizeof($a);
echo"<br>".$len."<br>";
for($j=0;$j<sizeof($a);$j++)
{
    echo$a[$j];
}
echo"<br>";
//sort()
$a=array("Mobile","Ac","Television","Computer");
sort($a);
print_r($a);
echo"<br>";
//rsort()
$a=array("Mobile","Ac","Television","Computer");
rsort($a);
print_r($a);
echo"<br>";
//asort()
$emp=array("name"=>"Ram","designation"=>"Accountant","city"=>"Mumbai");
asort($emp);
print_r($emp);
$std=array("fullname"=>"Satish","Age"=>22,"height"=>5.10,"Gender"=>'M');
asort($std);
foreach($std as$x=>$x_value)
{
    echo"Key=".$x.",Value=".$x_value;
    echo"<br>";
}
?>

