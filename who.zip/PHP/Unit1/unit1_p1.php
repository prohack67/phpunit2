<!-- Write a program in PHP to display "Learning PHP" in bold format. -->
<?php
echo"<br>"."hello World";
echo"<br>"."<b>Learning PHP</b>";
echo"<br>". 123;
?>