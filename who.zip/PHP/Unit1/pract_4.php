<?php
 $no=100;
 function printno()
 {
    global$no;
    $no=120;
    echo"<br>global variable inside function=".$no;
 }
 printno();
 echo"<br>global variable value=".$no;
 ?>