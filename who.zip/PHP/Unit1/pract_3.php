<?php 
 $no=90;
 function printno()
 {
    $no=80;
    echo"Local number=".$no;
 }
 printno();
 echo"<br>Outside function number=".$no;
 ?>