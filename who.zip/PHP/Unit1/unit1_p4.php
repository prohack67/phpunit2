<!-- create an array named $sub, assign five elements to it and display the elements assigned using for loop and for each statement  -->
 <?php
 $sub=array(1,2,3,4,5,55,66,77,88);
 $cnt=count($sub);//count function will give the total number of elements in array
 echo$cnt;
 for($i=0;$i<$cnt;$i++)
 {
    echo"<br>arr[".$i."]=".$sub[$i];
 }
 foreach($sub as $val)
 {
    echo"<br>".$val;
 }

 $m=array("banana",11,333.333,'A');
 print_r($m);//this function will print an array with key and value also with index and value.
 for($j=0;$j<count($m);$j++)
 {
    echo"<br>arr[".$j."]=".$m[$j];
 } 
 ?>