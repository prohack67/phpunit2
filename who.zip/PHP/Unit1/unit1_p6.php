<!-- write a program in PHP to demonstrate the use of multidimensional arrays. -->
 <?php
 $shop=array("mobile"=>array("samsung"=>"m12","mi"=>"note9 pro","apple"=>"i12"),
 "leptop"=>array("dell"=>"insp12","hp"=>"hp2200","lenovo"=>"Z350")
);
echo $shop["mobile"]["samsung"]."<br>";
echo $shop["mobile"]["mi"]."<br>";
echo $shop["mobile"]["apple"]."<br>";
echo $shop["leptop"]["lenovo"]."<br>";
?>