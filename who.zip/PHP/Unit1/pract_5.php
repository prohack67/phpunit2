<?php
function static_var()
{
    static$num=5;
    $sum=2;
    $sum++;
    $num++;
echo"<br> num=",$num;
echo" sum=",$sum;
}
static_var();
static_var();
?>