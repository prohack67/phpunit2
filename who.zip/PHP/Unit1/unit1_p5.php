<!-- create an array named $student, that sores 5 element bounded to a different keys and access the same using the key element. -->
 <?php
 $student=array("Name"=>"Hima Patel","Age"=>5,"Height"=>3.4,"City"=>"Ahmedabad");
 //print_r($student);
 echo $student["Name"]."<br>";
 echo $student["Age"]."<br>";
 echo $student["Height"]."<br>";
 echo $student["City"]."<br>";
 foreach($student as $key=>$val)
 {
    echo "<br>[".$key."]=".$val;
 }
 ?>