<!-- writwe a program in PHP to demonstrate the use of comments, echo and print -->
 <?php
 echo("below line is in comment");
 //echo("this line is in single lien comment");
 print"hello Asia";
 print 100;
 /*$age=35;
 print"Payal Patel age is".$age;
 print("this is a multiline comment in program");*/
 ?>