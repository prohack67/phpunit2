<!-- Create two functions in php, parameterized and non-parameterized for implementing string concatenation operation. -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form name="add" method="post" action="function.php">
    <label for="n1">Fname: </label><input type="text"name="fname"value="" /><br>
    <label for="n2">Lname: </label><input type="text"name="lname"value="" /><br>
    <input type="submit"name="submit"value="submit" />
    </form> 
</body>
</html>
