<?php
include ("connection.php");
    $db_create="create table product
    (Pro_Id int(3) unsigned auto_increment primary key,
    Pro_name varchar(30) not null,
    Pro_price float(5,2) not null,
    QOH int(5) not null)";
    $qry=mysqli_query($con,$db_create);
    if($qry)
    {
        echo "Product table created successfully";
    }
    else
    {
        echo "Product table not created.";
    }
?>