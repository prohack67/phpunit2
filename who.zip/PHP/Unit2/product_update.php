<?php
include("connection.php");
echo $Pro_Id=$_POST["Pro_Id"];
echo $qoh=$_POST["QOH"];
if(!empty($qoh))
{
    echo $update_qry="update product set QOH=$qoh where Pro_Id=$Pro_Id";
    $update_res=mysqli_query($con,$update_qry);
    if($update_res)
    {
        header("location:product_record.php");
    }
}
else
{
    header("location:unit2_Prog6.php?msg=Please Try Again");
}
?>