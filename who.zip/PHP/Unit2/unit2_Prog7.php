<?php
    include("connection.php");
    echo $Pro_Id=$_GET["pid"];

    if(!empty($Pro_Id))
    {
        echo $delete_qry="delete from product where Pro_Id=$Pro_Id";
        $delete_res=mysqli_query($con,$delete_qry);
        if($delete_res)
        {
            header("location:product_record.php");
        }
    }
    else
    {
        header("location:unit2_Prog7.php?msg=Please Try Again");
    }
?>