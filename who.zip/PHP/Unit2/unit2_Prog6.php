<?php
include("connection.php");
$pro_id=$_GET["pid"];
echo "pro_id".$pro_id;
$sel_product="select * from product where Pro_Id=$pro_id";
$res_product=mysqli_query($con,$sel_product);
$row_product=mysqli_fetch_array($res_product);
$pid=$row_product["Pro_Id"];
$qty=$row_product["QOH"];

if(isset($_GET["msg"]))
{
    echo $_GET["msg"];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="product_update.php" method="post">
        <table>
            <caption>Product Update</caption>
            <tr>
                <td><label for="product">Product Name</label></td>
                <td>
                    <select name="Pro_Id"><option value="">Please Select</option>
                <?php
                $sel_product="select * from product order by Pro_name ASC";
                $qry=mysqli_query($con,$sel_product);
                while($row_search=mysqli_fetch_array($qry))
                {
                    ?>
                    <option value="<?php echo $row_search["Pro_Id"];?>" <?php
                    if($row_search["Pro_Id"]==$pid){echo "selected";}else{echo "";}?>>
                    <?php echo $row_search["Pro_name"];?>
                </option>
                <?php
                }
                ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td><label for="quantity">Quantity</label></td>
                <td><input type="number" name="QOH" value="<?php echo $qty;?>"></td>
            </tr>
            <tr>
                <td colspan="2"><input type="submit" name="Submit" value="Submit">
            <input type="reset" name="reset" value="reset"></td>
            </tr>
        </table>
    </form>
</body>
</html>