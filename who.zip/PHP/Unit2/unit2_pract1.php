<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>display email with welcome message</title>
</head>
<body>
    <form action="prg1_submit.php" method="post">
     <!--we can set method get also-->
     <table>
        <tr>
            <td><label for="name">Name</label></td>
            <td><input type="text" name="fullname"></td>
        </tr>
        <tr>
            <td><label for="email">Email</label></td>
            <td><input type="email" name="email"></td>
        </tr>
        <tr>
            <td colspan="2"><input type="submit" name="Submit" value="Submit">
            <input type="reset" name="reset" value="reset"></td>
        </tr>
     </table>   
    </form>
</body>
</html>