<?php
$fullname=$_POST["fullname"];
$email=$_POST["email"];
//if form method is get then we use$_Get["fullname"];to receive data from form.
echo "Form Submit following Data<br>";
echo "Fullname=".$fullname."<br>";
echo "Email=$email<br>";
?>