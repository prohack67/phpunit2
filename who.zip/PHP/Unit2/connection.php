<?php
    $host="localhost";
    $user="root";
    $password="1234";
    $dbname="db2";
    $con=mysqli_connect($host,$user,$password,$dbname);
    if($con)
    {
        echo "Connection Established";
    }
    else
    {
        echo "Connection not Established";
    }
?>