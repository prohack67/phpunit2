<?php
include("connection.php");
$db_create="create database db2";
$qry=mysqli_query($con,$db_create);
if($qry)
{
    echo "Database Created Successfully";
}
else
{
    echo "Database not Created.";
}