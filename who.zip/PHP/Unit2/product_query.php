<?php
include("connection.php");
$productname=$_POST["Pro_name"];
$price=$_POST["Pro_price"];
$qoh=$_POST["Pro_QOH"];
if(!empty($productname)&& !empty($price)&& !empty($qoh))
{
    $ins_qry="INSERT INTO PRODUCT (Pro_name,Pro_price,QOH) VALUES ('$productname','$price','$qoh')";
    $res=mysqli_query($con,$ins_qry);
    if($res)
    {
        header("location:product_record.php");
    }
}
else
{
    header("location:unit2_pract4.php?msg=Please Try Again");
}
?>