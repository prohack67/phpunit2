<?php
$fullname=$_POST["fullname"];
$email=$_POST["email"];

echo "Form Submit Following Data<br>";
echo "Fullname=".$fullname."<br>";
echo "Email=$email<br>";
?>