<?php
$shop=array("Mobile"=>array("Samsung"=>"S23","Redmi"=>"Redmi Note 13","Realme"=>"P1"),
            "Laptop"=>array("Dell"=>"Latitude 5490","Lenovo"=>"Ideapad slim3","HP"=>"Inspiron 15"));
            
    echo $shop["Mobile"]["Samsung"]."<br>";
    echo $shop["Mobile"]["Redmi"]."<br>";
    echo $shop["Mobile"]["Realme"]."<br>";
    echo $shop["Laptop"]["Dell"]."<br>";
    echo $shop["Laptop"]["Lenovo"]."<br>";
    echo $shop["Laptop"]["HP"]."<br>";
?>