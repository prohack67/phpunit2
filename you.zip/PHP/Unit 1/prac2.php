<?php 
    echo ("below line is in comment<br>");
    //echo ("This line is in single line comment");
    print "Hello Asia<br>";
    print 100;
    /* $age=24;
    print "Payal Patel age is".$age;
    print("this is a multiline comment in program");*/
?>