<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form name ="add" method="post" action="function.php">
    <label for="n1">fname</label><input type="text" name="fname" value=""/><br>
    <label for="n2">lname</label><input type="text" name="lname" value=""/><br>
    <input type="submit" name="submit" value="submit"/>
</form>
</body>
</html>