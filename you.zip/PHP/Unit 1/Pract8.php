<?php
    echo "php version =".phpversion();
    Phpinfo();
        phpinfo(INFO_MODULES);
?>