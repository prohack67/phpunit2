<?php 
    echo "Hello<br>";
    echo "Learning PHP<br>";
    echo 123
?>