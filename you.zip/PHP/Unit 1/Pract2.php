<?php echo"Hello";?>
<?php 
 $price=10;
 $Price=30.50;
 $PRICE=40;?><br>
  <?php ECHO ("the Price=$Price");?><br>
<?php print("The PRICE=$PRICE");?><br>
<?php printf(format: "The price=$price");?>